# CGM client portal — private local development

This is a separate local development build for the CGM client portal. It is
not connected to the public CGM website, GitHub Pages, a Cloudflare account,
or real client records.

It runs the same Cloudflare Pages Functions model locally with isolated D1,
R2, and KV simulations. The sample household is **The Hawthorn Household**
(`hawthorn-household`) and is strictly placeholder data.

## Start locally

1. Copy `.dev.vars.example` to `.dev.vars`, then replace the local test
   password and session secret.
2. Run `npm install`.
3. Run `npm run db:init`, then `npm run db:seed`.
4. Run `npm run dev` and open `http://127.0.0.1:8788`.

Use `hawthorn-household` from the client login page. In this local build the
one-time email link appears on that page after requesting it; it is captured
locally and nothing is emailed. Sign in to the staff portal with the values
from `.dev.vars`.

## Included scope

- Household-only client portal with visit notes, history, client notes and
  private image uploads.
- Staff dashboard for household creation, updates, activation and private
  administration.
- One-time magic links, HttpOnly sessions and server-side household checks.
- Local-only D1/R2/KV data and development email capture.

## Safety boundary

Do not run a deployment command from this project. This build has no production
database, image bucket, mail key, client data or custom domain configured.
When the experience is approved, the next stage is a separate Cloudflare preview
environment with new resources and secrets — still before any production launch.
